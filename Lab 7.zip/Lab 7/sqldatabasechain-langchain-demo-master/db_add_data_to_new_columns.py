import psycopg2
import environ
env = environ.Env()
environ.Env.read_env()
# Establish a connection to the PostgreSQL database
conn = psycopg2.connect(
host='localhost',
port=5432,
user='postgres',
password=env('DBPASS'),
database=env('DATABASE')
)
# Create a cursor object to execute SQL commands
cursor = conn.cursor()
#################################################
#Use the code in this section to add data to new columns
#################################################
task1='Complete the web page design'
Note1_task1 = 'www.ee104sjsu.edu'
Note2_task1 = 'for EE104'
sql = """ UPDATE tasks
SET Note1= %s
WHERE task = %s"""
cursor.execute(sql, (Note1_task1, task1))
sql = """ UPDATE tasks
SET Note2= %s
WHERE task = %s"""
cursor.execute(sql, (Note2_task1, task1))
task2='Create login and signup pages'
Note1_task2 = 'Login EE104'
Note2_task2 = 'Password ee104sjsu'
sql = """ UPDATE tasks
SET Note1= %s
WHERE task = %s"""
cursor.execute(sql, (Note1_task2, task2))
sql = """ UPDATE tasks
SET Note2= %s
WHERE task = %s"""
cursor.execute(sql, (Note2_task2, task2))
task3='Product management'
Note1_task3 = 'product webpage'
Note2_task3 = 'lab team is the manager'
sql = """ UPDATE tasks
SET Note1= %s

WHERE task = %s"""
cursor.execute(sql, (Note1_task3, task3))
sql = """ UPDATE tasks
SET Note2= %s
WHERE task = %s"""
cursor.execute(sql, (Note2_task3, task3))
task4='Cart and wishlist creation'
Note1_task4 = 'Cart is empty '
Note2_task4 = 'Wishlist is empty '
sql = """ UPDATE tasks
SET Note1= %s
WHERE task = %s"""
cursor.execute(sql, (Note1_task4, task4))
sql = """ UPDATE tasks
SET Note2= %s
WHERE task = %s"""
cursor.execute(sql, (Note2_task4, task4))
task5='Payment gateway integration'
Note1_task5 = 'Gateway to the bank'
Note2_task5 = 'Bank of SJSU'
sql = """ UPDATE tasks
SET Note1= %s
WHERE task = %s"""
cursor.execute(sql, (Note1_task5, task5))
sql = """ UPDATE tasks
SET Note2= %s
WHERE task = %s"""
cursor.execute(sql, (Note2_task5, task5))
task6='Order management'
Note1_task6 = 'Order via TicketMaster'
Note2_task6 = 'There is no fee to order'
sql = """ UPDATE tasks
SET Note1= %s
WHERE task = %s"""
cursor.execute(sql, (Note1_task6, task6))
sql = """ UPDATE tasks
SET Note2= %s
WHERE task = %s"""
cursor.execute(sql, (Note2_task6, task6))
#End of Section
##########################################
# Commit the changes and close the connection
conn.commit()
conn.close()