import psycopg2
import environ
env = environ.Env()
environ.Env.read_env()
# Establish a connection to the PostgreSQL database
conn = psycopg2.connect(
host='localhost',
port=5432,
user='postgres',
password=env('DBPASS'),
database=env('DATABASE')
)
# Create a cursor object to execute SQL commands
cursor = conn.cursor()
##############################################################
#Use the code in this section to update a task being completed
##############################################################
task_completed = 'Product management'
is_completed = 'True'
date_completed = '2024-03-09'
sql = """ UPDATE tasks
SET completed= %s
WHERE task = %s"""
cursor.execute(sql, (is_completed, task_completed))
sql = """ UPDATE tasks
SET completion_date= %s
WHERE task = %s"""
cursor.execute(sql, (date_completed, task_completed))
#End of Section
############################################################
# Commit the changes and close the connection
conn.commit()
conn.close()