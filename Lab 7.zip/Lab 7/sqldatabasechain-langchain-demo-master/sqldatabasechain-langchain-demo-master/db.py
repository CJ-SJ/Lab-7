import psycopg2
import environ
env = environ.Env()
environ.Env.read_env()

# Establish a connection to the PostgreSQL database
conn = psycopg2.connect(
    host='localhost',
    port=5432,
    user='postgres',
    password=env('DBPASS'),
    database=env('DATABASE')
)

# Create a cursor object to execute SQL commands
cursor = conn.cursor()

# Create the patients table if it doesn't exist
cursor.execute('''CREATE TABLE IF NOT EXISTS patients (
             id SERIAL PRIMARY KEY,
             first_name TEXT NOT NULL,
             middle_name TEXT,
             last_name TEXT NOT NULL,
             phone_number TEXT NOT NULL,
             email TEXT NOT NULL UNIQUE,
             first_vaccination_date DATE,
             second_vaccination_date DATE
             )''')

# Insert sample data into the patients table
cursor.execute('''INSERT INTO patients (first_name, middle_name, last_name, phone_number, email, first_vaccination_date, second_vaccination_date) 
                  VALUES (%s, %s, %s, %s, %s, %s, %s)''',
               ('Chris', 'H.', 'Pham', '14083321091', 'ee104sjsu@gmail.com', '2022-9-18', '2023-02-15'))

cursor.execute('''INSERT INTO patients (first_name, middle_name, last_name, phone_number, email, first_vaccination_date, second_vaccination_date) 
                  VALUES (%s, %s, %s, %s, %s, %s, %s)''',
               ('Jane', None, 'Smith', '9876543210', 'jane.smith@example.com', '2023-02-20', '2023-03-20'))

cursor.execute('''INSERT INTO patients (first_name, middle_name, last_name, phone_number, email, first_vaccination_date, second_vaccination_date) 
                  VALUES (%s, %s, %s, %s, %s, %s, %s)''',
               ('Emily', 'R.', 'Clark', '5551234567', 'emily.clark@example.com', '2023-03-10', '2023-04-10'))

# Commit the changes and close the connection
conn.commit()
conn.close()
