import psycopg2
import environ
env = environ.Env()
environ.Env.read_env()
# Establish a connection to the PostgreSQL database
conn = psycopg2.connect(
host='localhost',
port=5432,
user='postgres',
password=env('DBPASS'),
database=env('DATABASE')
)
# Create a cursor object to execute SQL commands
cursor = conn.cursor()
######################################################################
#Use the code in this section to add two columns to an existing table
######################################################################
sql = """
ALTER TABLE tasks
ADD COLUMN Note1 VARCHAR(25),
ADD COLUMN Note2 VARCHAR(25);
"""
cursor.execute(sql)
#End of Section
############################################################
# Commit the changes and close the connection
conn.commit()
conn.close()